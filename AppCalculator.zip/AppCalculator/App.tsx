import React from 'react'
import { SafeAreaView, StatusBar, Text } from 'react-native'
import { CalculadoraScreen } from './src/screens/CalculadoraScreen';
import { styles } from './src/themes/AppTheme';

const App = () => {
  return (

    <SafeAreaView style={ styles.fondo }>

      <StatusBar 
        backgroundColor= 'black'
        barStyle='light-content'
      />
      <Text style={{ paddingHorizontal:10, paddingVertical:10, color:'white', fontSize: 15 }}>Gilbert's Calculator</Text>


      <CalculadoraScreen />

    </SafeAreaView>

  )
}

export default App;
